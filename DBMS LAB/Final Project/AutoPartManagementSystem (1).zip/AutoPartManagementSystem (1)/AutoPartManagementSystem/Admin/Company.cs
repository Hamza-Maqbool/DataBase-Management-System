﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject.Admin
{
    public partial class Company : Form
    {
        public Company()
        {
            InitializeComponent();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            lblData.ForeColor = ThemeColor.PrimaryColor;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void Company_Load(object sender, EventArgs e)
        {
            LoadTheme();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            var con = AutoPartManagementSystem.Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Company", con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            this.dataGridView1.DataSource = dt;
        }
    }
}
