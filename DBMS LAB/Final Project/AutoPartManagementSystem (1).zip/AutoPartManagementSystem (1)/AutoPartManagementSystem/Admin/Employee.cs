﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject.Admin
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            lblData.ForeColor = ThemeColor.PrimaryColor;
        }
        private void Employee_Load(object sender, EventArgs e)
        {
            LoadTheme();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            FinalProject.BL.Employee emp = new BL.Employee();
            emp.Name = txtname.Text;
            emp.Email = textemail.Text;
            emp.Position = textPosition.Text;
            emp.Salary = (int)guna2NumericUpDown1.Value;
            emp.Hired_date = DOB.Value.ToString("yyyy-MM-dd");
            emp.Contact = txtContact.Text;
            emp.Address = txtAddress.Text;
            var con = AutoPartManagementSystem.Configuration.getInstance().getConnection();
            string query = "insert into Employees Values('" + emp.Name + "','" + emp.Email + "', '" + emp.Contact + "', '" + emp.Address + "', " + emp.Hired_date + "," + emp.Salary + ", '" + emp.Position + "')" ;
            SqlCommand cmd2 = new SqlCommand(query, con);
            txtname.Text = query;
            cmd2.ExecuteNonQuery();
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            var con = AutoPartManagementSystem.Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Employees", con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            this.dataGridView1.DataSource = dt;
        }
    }
}
