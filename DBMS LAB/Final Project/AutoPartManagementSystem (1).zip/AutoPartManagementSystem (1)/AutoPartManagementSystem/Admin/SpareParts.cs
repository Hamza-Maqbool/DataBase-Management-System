﻿using AutoPartManagementSystem;
using FinalProject.BL;
using FinalProject.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace FinalProject.Admin
{
    public partial class SpareParts : Form
    {
        public int count = 0, count1 = 0;
        public SpareParts()
        {
            InitializeComponent();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            lblData.ForeColor = ThemeColor.PrimaryColor;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                spareparts spareparts = new spareparts();
                spareparts.Name = txtname.Text;
                spareparts.Description = richTextBox1.Text;
                spareparts.Cost = (int)guna2NumericUpDown1.Value;
                spareparts.Price = (int)guna2NumericUpDown2.Value;
                spareparts.Quantity = (int)guna2NumericUpDown3.Value;

                int companyid, categoryid;
                var con = AutoPartManagementSystem.Configuration.getInstance().getConnection();
                string query = "Select id from company where name = '" + this.comboBox1.SelectedItem.ToString() + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                companyid = (int)cmd.ExecuteScalar();
                string query1 = "Select id from Category where name = '" + this.comboBox1.SelectedItem.ToString() + "'";
                SqlCommand cmd1 = new SqlCommand(query1, con);
                categoryid = (int)cmd.ExecuteScalar();
                query = "insert into SpareParts Values('" + spareparts.Name + "', '" + spareparts.Description + "'," + spareparts.Cost + "," + spareparts.Price + "," + spareparts.Quantity + "," + companyid + "," + categoryid + ")";
                SqlCommand cmd2 = new SqlCommand(query, con);
                txtname.Text = query;
                cmd2.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void lblReg_Click(object sender, EventArgs e)
        {

        }

        private void lblData_Click(object sender, EventArgs e)
        {

        }

        private void SpareParts_Load(object sender, EventArgs e)
        {
            LoadTheme();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (count == 0)
                {
                    var con = FinalProject.DL.Configuration.getInstance().getConnection();
                    SqlCommand command = new SqlCommand("Select * from Company", con);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        this.comboBox1.Items.Add(reader.GetString(1));
                        count++;
                    }
                    reader.Close();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            var con = AutoPartManagementSystem.Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from SpareParts", con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            this.dataGridView1.DataSource = dt;
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            /*FinalProject.BL.spareparts spareparts = new FinalProject.BL.spareparts();
            try
            {
                customer.Name= dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString();
                customer.cCost = dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString();
                Price = dataGridView2.Rows[e.RowIndex].Cells[3].Value.ToString();
                Quantity = dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString();
                CompanyId = int.Parse(dataGridView2.Rows[e.RowIndex].Cells[5].Value.ToString());
                CategoryId = int.Parse(dataGridView2.Rows[e.RowIndex].Cells[6].Value.ToString());
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }*/
        }

        private void comboBox2_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (count1 == 0)
                {
                    var con = FinalProject.DL.Configuration.getInstance().getConnection();
                    SqlCommand command = new SqlCommand("Select * from Category", con);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        this.comboBox2.Items.Add(reader.GetString(1));
                        count1++;
                    }
                    reader.Close();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
