﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject.Admin
{
    public partial class WareHouse : Form
    {
        public WareHouse()
        {
            InitializeComponent();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            lblData.ForeColor = ThemeColor.PrimaryColor;
        }
        private void WareHouse_Load(object sender, EventArgs e)
        {
            LoadTheme();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string location = txtLocation.Text;
            int Capacity = (int)guna2NumericUpDown1.Value;
            int stock_level = (int)guna2NumericUpDown2.Value;

            var con = AutoPartManagementSystem.Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("insert into WareHouse Values('" + name + "','" + location + "'," + Capacity + "," + stock_level + ")", con);
            cmd.ExecuteNonQuery();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            var con = AutoPartManagementSystem.Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from WareHouse", con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            this.dataGridView1.DataSource = dt;
        }
    }
}
