﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.BL
{
    public class Employee
    {
        private string name;
        private string email;
        private string contact;
        private string address;
        private string hired_date;
        private int salary;
        private string position;

        public string Name { get => name; set => name = value; }
        public string Email { get => email; set => email = value; }
        public string Contact { get => contact; set => contact = value; }
        public string Address { get => address; set => address = value; }
        public string Hired_date { get => hired_date; set => hired_date = value; }
        public int Salary { get => salary; set => salary = value; }
        public string Position { get => position; set => position = value; }
    }
}
