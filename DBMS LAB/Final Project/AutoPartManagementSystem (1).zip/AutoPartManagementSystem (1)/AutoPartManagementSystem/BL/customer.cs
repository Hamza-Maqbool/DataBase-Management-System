﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.BL
{
    public class customer
    {
        private string name;
        private string password;
        private string email;
        private string Address;
        private string phone;

        public string Name { get => name; set => name = value; }
        public string Password { get => password; set => password = value; }
        public string Email { get => email; set => email = value; }
        public string Address1 { get => Address; set => Address = value; }
        public string Phone { get => phone; set => phone = value; }
    }
}
