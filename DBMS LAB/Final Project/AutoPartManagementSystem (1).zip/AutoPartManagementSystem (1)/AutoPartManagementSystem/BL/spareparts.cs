﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.BL
{
    public class spareparts
    {
        private string name;
        private string description;
        private int cost;
        private int price;
        private int quantity;

        public string Name { get => name; set => name = value; }
        public string Description { get => description; set => description = value; }
        public int Cost { get => cost; set => cost = value; }
        public int Price { get => price; set => price = value; }
        public int Quantity { get => quantity; set => quantity = value; }
    }
}
