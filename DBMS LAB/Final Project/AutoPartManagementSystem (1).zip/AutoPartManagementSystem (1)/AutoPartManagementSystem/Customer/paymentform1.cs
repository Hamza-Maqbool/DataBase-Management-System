﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FinalProject.Customer;
using FinalProject.DL;

namespace FinalProject.Customer
{
    public partial class paymentform1 : Form
    {
        public paymentform1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            decimal totalPrice = 0;

            var con = Configuration.getInstance().getConnection();
            using (SqlCommand cmd = new SqlCommand("SELECT SUM(S.price) FROM SpareParts as S Join Cart as C on S.id = C.SparePartsID", con))
            {
                object result = cmd.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    totalPrice = Convert.ToDecimal(result);
                }
                else
                {
                    // Handle the case where the result is null or DBNull.Value
                }
            }
            MessageBox.Show("Your Account Detect " + totalPrice.ToString());
            paymentform1 f = new paymentform1();
            f.Close();
        }
    }
}
