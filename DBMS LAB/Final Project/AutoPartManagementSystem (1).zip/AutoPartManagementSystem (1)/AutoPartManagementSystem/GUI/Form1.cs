﻿using FinalProject.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AutoPartManagementSystem;
using FinalProject;
using FinalProject.DL;
using System.Data.SqlClient;

namespace AutoPartManagementSystem.GUI
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            customer cust = new customer();
            cust.Name = this.txtbox1.Text;
            cust.Password = this.txtPassword.Text;
            cust.Email = this.maskedTextBox1.Text;
            cust.Address1 = this.maskedTextBox2.Text;
            cust.Phone = this.maskedTextBox3.Text;

            var con = FinalProject.DL.Configuration.getInstance().getConnection();
            try
            {
                using (SqlCommand command = new SqlCommand("insert into Customer values(@Name, @Email, @1, @Address1, @Password)", con))
                {
                    command.Parameters.AddWithValue("@Name", cust.Name);
                    command.Parameters.AddWithValue("@Email", cust.Email);
                    command.Parameters.AddWithValue("@1", cust.Phone);
                    command.Parameters.AddWithValue("@Address1", cust.Address1);
                    command.Parameters.AddWithValue("@Password", cust.Password);
                    command.ExecuteNonQuery();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
