﻿using FinalProject.Admin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoPartManagementSystem.GUI
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 Form = new Form1();
            Form.Show();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string password1 = "@@@@@@@@@@@@@@@@@@@@@@@@";
            string password = txtbox1.Text;
            string email = maskedTextBox1.Text;
            if (password == "admin" && email == "admin@gmail.com" && comboBox1.SelectedIndex == 0)
            {
                AdminForm form = new AdminForm();
                form.Show();
            }
            else
            {
                var con = FinalProject.DL.Configuration.getInstance().getConnection();
                using (SqlCommand command = new SqlCommand("Select password from Customer where email = '" + email + "'", con))
                {
                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        password1 = result.ToString();
                        if (password1 == password)
                        {
                            if (comboBox1.SelectedIndex == 1)
                            {
                                FinalProject.CustomerMainPage Form = new FinalProject.CustomerMainPage();
                                Form.Show();
                            }
                            else
                            {
                                MessageBox.Show("Enter a valid User..");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Enter a valid User");
                    }
                }
            }
            
        }
    }
}
