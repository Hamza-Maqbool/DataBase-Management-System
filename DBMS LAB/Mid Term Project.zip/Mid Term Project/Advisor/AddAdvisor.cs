﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Advisor
{
    public partial class AddAdvisor : Form
    {
        public AddAdvisor()
        {
            InitializeComponent();
        }
        private bool checkID(string s)
        {
            for (int i = 0; i < s.Length; i++)
            {
                if (!Char.IsDigit(s[i]))
                {
                    return false;
                }
            }
            return true;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrEmpty(txtSalary.Text) || string.IsNullOrEmpty(txtContact.Text) || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtFirstName.Text) || string.IsNullOrEmpty(txtLastName.Text))
            {
                MessageBox.Show("Please Fill All Queries...");
            }
            else
            {

                if (!checkID(txtSalary.Text))
                {
                    txtSalary.Text = "*Salary can only consist of digits.";
                    txtSalary.Visible = true;
                }
                else
                {
                    try
                    {
                        var con = Configuration.getInstance().getConnection();
                        SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[Person](FirstName,LastName,Contact,Email,DateOfBirth,Gender) VALUES (@FirstName,@LastName, @Contact,@Email,@DOB, @Gender) " +
                            "insert into [dbo].[Advisor](Id, Salary, Designation) VALUES((SELECT Id FROM Person WHERE FirstName = @FirstName AND LastName = @LastName AND Contact = @Contact AND Email = @Email AND DateOfBirth = @DOB AND Gender = @Gender), @Salary, @Designation); ", con);
                        cmd.Parameters.AddWithValue("@Salary", int.Parse(txtSalary.Text));
                        cmd.Parameters.AddWithValue("@Designation", Destination.SelectedIndex + 6);
                        cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                        cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                        cmd.Parameters.AddWithValue("@Contact", txtContact.Text);
                        cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                        cmd.Parameters.AddWithValue("@Gender", Gender.SelectedIndex + 1);
                        DOBSelect.Format = DateTimePickerFormat.Custom;
                        DOBSelect.CustomFormat = "yyyy-MM-dd";
                        cmd.Parameters.AddWithValue("@DOB", DOBSelect.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Successfully saved");
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }

            }
        }

        private void AddAdvisor_Load(object sender, EventArgs e)
        {
            this.StartPosition = FormStartPosition.CenterScreen;
            this.CenterToScreen();
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select Value from Lookup where Category = 'DESIGNATION'");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            List<string> list = new List<string>();
            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                string s = dataTable.Rows[i]["Value"].ToString();
                list.Add(s);
            }
            Destination.DataSource = list;


            //GENDER DATA SOURCE
            SqlCommand cmd1 = new SqlCommand("select Value from Lookup where Category = 'GENDER'");
            cmd1.Connection = con;
            SqlDataReader sqlData1 = cmd1.ExecuteReader();
            DataTable dataTable1 = new DataTable();
            dataTable1.Load(sqlData1);
            List<string> list1 = new List<string>();
            for (int i = 0; i < dataTable1.Rows.Count; i++)
            {
                string s = dataTable1.Rows[i]["Value"].ToString();
                list1.Add(s);
            }
            Gender.DataSource = list1;
        }
    }
}
