﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Advisor
{
    public partial class AddAssignAdvisor : Form
    {
        public AddAssignAdvisor()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            int advisor = 0;
            if (string.IsNullOrEmpty(pidtxt.Text) || string.IsNullOrEmpty(Aidtxt.Text))
            {
                MessageBox.Show("Please fill all queries...");
            }
            else
            {
                try
                {
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("insert into ProjectAdvisor(AdvisorId , ProjectId, AdvisorRole, AssignmentDate) values (@AdvisorId , @ProjectId , @AdvisorRole ,@AssignmentDate)", con);
                    cmd.Parameters.AddWithValue("@ProjectId", int.Parse(pidtxt.Text));
                    cmd.Parameters.AddWithValue("@AdvisorId", int.Parse(Aidtxt.Text));
                    guna2DateTimePicker1.Format = DateTimePickerFormat.Custom;
                    guna2DateTimePicker1.CustomFormat = "yyyy-MM-dd";
                    cmd.Parameters.AddWithValue("@AssignmentDate", guna2DateTimePicker1.Text);
                    if (ADVISORR.SelectedIndex == 1)
                    {
                        advisor = 11;
                    }
                    if (ADVISORR.SelectedIndex == 2)
                    {
                        advisor = 12;
                    }
                    if (ADVISORR.SelectedIndex == 3)
                    {
                        advisor = 14;
                    }
                    cmd.Parameters.AddWithValue("@AdvisorRole", advisor);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Advisor Assign Successfully...");
                    this.Close();
                }
                catch
                {
                    MessageBox.Show("Advisor is Already Exits...");
                }

            }
        }
    }
}
