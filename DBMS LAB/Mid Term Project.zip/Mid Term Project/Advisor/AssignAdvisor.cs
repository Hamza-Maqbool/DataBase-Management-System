﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Advisor
{
    public partial class AssignAdvisor : UserControl
    {
        public AssignAdvisor()
        {
            InitializeComponent();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            refresh();
        }
        private void refresh()
        {
            dataGridView1.DataSource = null;
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select PA.AdvisorId , PA.ProjectId ,  PA.AssignmentDate, L.Value\r\n  as AdvisorRole from ProjectAdvisor as PA \r\njoin Lookup as L\r\n on L.Id = PA.AdvisorRole");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            dataGridView1.DataSource = dataTable;
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            AddAssignAdvisor f = new AddAssignAdvisor();
            f.Show();
        }
    }
}
