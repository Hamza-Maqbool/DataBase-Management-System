﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Advisor
{
    public partial class EditAddvisor : Form
    {
        private int IDs;
        private int genderI, DesignationI;
        public EditAddvisor(string FirstName, string LastName, string Contact, string email, int Salary, int Gender, int Designations, string DOB, int ID)
        {
            InitializeComponent();
            txtContact.Text = Contact;
            txtEmail.Text = email;
            txtFirstName.Text = FirstName;
            txtLastName.Text = LastName;
            genderI = Gender;
            DesignationI = Designations;
            txtSalary.Text = Salary.ToString();
            DOBSelect.Value = DateTime.Parse(DOB);
            IDs = ID;
        }

        private void EditAddvisor_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd1 = new SqlCommand("select Value from Lookup where Category = 'GENDER'");
            cmd1.Connection = con;
            SqlDataReader sqlData1 = cmd1.ExecuteReader();
            DataTable dataTable1 = new DataTable();
            dataTable1.Load(sqlData1);
            List<string> list1 = new List<string>();
            for (int i = 0; i < dataTable1.Rows.Count; i++)
            {
                string s = dataTable1.Rows[i]["Value"].ToString();
                list1.Add(s);
            }
            Gender.DataSource = list1;
            Gender.SelectedIndex = genderI - 1;

            SqlCommand cmd = new SqlCommand("select Value from Lookup where Category = 'DESIGNATION'");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            List<string> list = new List<string>();
            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                string s = dataTable.Rows[i]["Value"].ToString();
                list.Add(s);
            }
            Destination.DataSource = list;
            Destination.SelectedIndex = DesignationI - 1;
        }
        private bool checkID(string s)
        {
            for (int i = 0; i < s.Length; i++)
            {
                if (!Char.IsDigit(s[i]))
                {
                    return false;
                }
            }
            return true;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrEmpty(txtSalary.Text) || string.IsNullOrEmpty(txtContact.Text) || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtFirstName.Text) || string.IsNullOrEmpty(txtLastName.Text))
            {
                MessageBox.Show("Please Fill All Queries...");
            }
            else
            {

                if (!checkID(txtSalary.Text))
                {
                    txtSalary.Text = "*Salary can only consist of digits.";
                    txtSalary.Visible = true;
                }
                else
                {
                    try
                    {
                        var con = Configuration.getInstance().getConnection();
                        SqlCommand cmd = new SqlCommand("update [dbo].[Person] " +
                        " set FirstName = @FirstName, LastName = @LastName, Contact = @Contact, Email = @Email, DateOfBirth = @DOB, Gender = @Gender " +
                        " where Id = @ID; " +
                        " update [dbo].[Advisor]" +
                        " set Designation = @Designation, Salary = @Salary" +
                        " where Id = @ID ", con);
                        cmd.Parameters.AddWithValue("@Salary", int.Parse(txtSalary.Text));
                        cmd.Parameters.AddWithValue("@Designation", Destination.SelectedIndex + 6);
                        cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                        cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                        cmd.Parameters.AddWithValue("@Contact", txtContact.Text);
                        cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                        cmd.Parameters.AddWithValue("@Gender", Gender.SelectedIndex + 1);
                        cmd.Parameters.AddWithValue("@ID", IDs);
                        DOBSelect.Format = DateTimePickerFormat.Custom;
                        DOBSelect.CustomFormat = "yyyy-MM-dd";
                        cmd.Parameters.AddWithValue("@DOB", DOBSelect.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Successfully Updated");
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }


        }
    }
}
