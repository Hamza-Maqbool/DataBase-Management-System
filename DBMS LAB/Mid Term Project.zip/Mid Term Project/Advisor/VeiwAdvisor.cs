﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Advisor
{
    public partial class VeiwAdvisor : UserControl
    {
        int ID = -1;
        string FirstName;
        string LastName, Contact, Email, DOB;
        int salary, GEnder, Designation;

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            if (ID != -1)
            {
                try
                {
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("delete Advisor where Id = @ID; delete Person where Id = @ID;");
                    cmd.Parameters.AddWithValue("@ID", ID);
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Has Been Deleted Successfully...");
                    refresh();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }

            }
            else
            {
                MessageBox.Show("Please Select A Row To Deleteo...");
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (ID != -1)
            {
                EditAddvisor form = new EditAddvisor(FirstName, LastName, Contact, Email, salary, GEnder, Designation, DOB, ID);
                form.Show();
            }
            else
            {
                MessageBox.Show("Please select an entry to edit...");
            }
        }

        public VeiwAdvisor()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            AddAdvisor f = new AddAdvisor();
            f.Show();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            refresh();
        }
        private void refresh()
        {
            dataGridView1.DataSource = null;
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select P1.Id , P1.FirstName , P1.LastName ,L.Value as Gender, P1.Contact , P1.Email , P1.DateOfBirth , P1.Designation , P1.Salary \r\nfrom Lookup as L\r\njoin (select A.Id , P.FirstName , P.LastName , P.Contact , P.Email , P.DateOfBirth , L.Value as Designation , P.Gender , A.Salary \r\nfrom Advisor as A\r\njoin Person  as P\r\non P.Id = A.Id\r\njoin Lookup as L\r\non L.Id = A.Designation) as P1\r\non P1.Gender = L.Id");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            dataGridView1.DataSource = dataTable;
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            FirstName = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            LastName = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            DOB = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            if (dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString() == "Male")
            {
                GEnder = 1;
            }
            else
            {
                GEnder = 2;
            }
            Contact = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            Email = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            if (dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString() == "Professor")
            {
                Designation = 1;
            }
            else if (dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString() == "Associate Professor")
            {
                Designation = 2;
            }
            else if (dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString() == "Assisstant Professor")
            {
                Designation = 3;
            }
            else if (dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString() == "Lecturer")
            {
                Designation = 4;
            }
            else
            {
                Designation = 5;
            }
            salary = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString());
        }
    }
}
