﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Evaluation
{
    public partial class AddEvaluation : Form
    {
        public AddEvaluation()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(weighttxt.Text) || string.IsNullOrEmpty(markstxt.Text) || string.IsNullOrEmpty(nametxt.Text))
            {
                MessageBox.Show("Please fill all queries...");
            }
            else
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("insert into Evaluation(Name , TotalMarks, TotalWeightage) values (@Name, @TotalMarks, @TotalWeightage)", con);
                cmd.Parameters.AddWithValue("@Name", nametxt.Text);
                cmd.Parameters.AddWithValue("@TotalMarks", int.Parse(markstxt.Text));
                cmd.Parameters.AddWithValue("@TotalWeightage", int.Parse(weighttxt.Text));
                cmd.ExecuteNonQuery();
                MessageBox.Show("Project Added Successfully...");
                this.Close();
            }
        }
    }
}
