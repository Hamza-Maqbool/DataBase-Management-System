﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Evaluation
{
    public partial class AddMarkEvaluation : Form
    {
        public AddMarkEvaluation()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Eidtxt.Text) || string.IsNullOrEmpty(Gidtxt.Text) || string.IsNullOrEmpty(OMtxt.Text))
            {
                MessageBox.Show("Please fill all queries...");
            }
            else
            {
                try
                {
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("insert into GroupEvaluation(GroupId , EvaluationId, ObtainedMarks, EvaluationDate) values (@GroupId , @EvaluationId , @ObtainedMarks ,@EvaluationDate)", con);
                    cmd.Parameters.AddWithValue("@GroupId", int.Parse(Gidtxt.Text));
                    cmd.Parameters.AddWithValue("@EvaluationId", int.Parse(Eidtxt.Text));
                    cmd.Parameters.AddWithValue("@ObtainedMarks", int.Parse(OMtxt.Text));
                    guna2DateTimePicker1.Format = DateTimePickerFormat.Custom;
                    guna2DateTimePicker1.CustomFormat = "yyyy-MM-dd";
                    cmd.Parameters.AddWithValue("@EvaluationDate", guna2DateTimePicker1.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Evaluation Assign Successfully...");
                    this.Close();
                }
                catch
                {
                    MessageBox.Show("ID NOT FOUND");
                }
            }
        }
    }
}

