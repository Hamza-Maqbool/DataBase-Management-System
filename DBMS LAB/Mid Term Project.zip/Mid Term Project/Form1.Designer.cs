﻿
namespace MidTermProject
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SidebarTimer = new System.Windows.Forms.Timer(this.components);
            this.StudentTimer = new System.Windows.Forms.Timer(this.components);
            this.Studentcontianer = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.StudentButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.menu = new System.Windows.Forms.PictureBox();
            this.SideBar = new System.Windows.Forms.FlowLayoutPanel();
            this.AdvisorContainer = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Advisorbtn = new System.Windows.Forms.Button();
            this.ProjectContainer = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.projectbtn = new System.Windows.Forms.Button();
            this.EvaluationContainer = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.Evaluationbtn = new System.Windows.Forms.Button();
            this.GroupContainer = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.ReportContainer = new System.Windows.Forms.Panel();
            this.button13 = new System.Windows.Forms.Button();
            this.AdvisorTimer = new System.Windows.Forms.Timer(this.components);
            this.ProjectTimer = new System.Windows.Forms.Timer(this.components);
            this.EvaluationTimer = new System.Windows.Forms.Timer(this.components);
            this.GroupTimer = new System.Windows.Forms.Timer(this.components);
            this.main1 = new MidTermProject.main();
            this.markEvaluation1 = new MidTermProject.Evaluation.MarkEvaluation();
            this.assignAdvisor1 = new MidTermProject.Advisor.AssignAdvisor();
            this.assignProject1 = new MidTermProject.Project.AssignProject();
            this.addSGroup1 = new MidTermProject.Groups.AddSGroup();
            this.veiwGroup1 = new MidTermProject.Groups.VeiwGroup();
            this.evaluationVeiw1 = new MidTermProject.Evaluation.EvaluationVeiw();
            this.projectVeiw1 = new MidTermProject.Project.ProjectVeiw();
            this.veiwAdvisor1 = new MidTermProject.Advisor.VeiwAdvisor();
            this.student1 = new MidTermProject.Student();
            this.genrateReport1 = new MidTermProject.GenrateReport();
            this.Studentcontianer.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menu)).BeginInit();
            this.SideBar.SuspendLayout();
            this.AdvisorContainer.SuspendLayout();
            this.ProjectContainer.SuspendLayout();
            this.EvaluationContainer.SuspendLayout();
            this.GroupContainer.SuspendLayout();
            this.ReportContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // SidebarTimer
            // 
            this.SidebarTimer.Interval = 10;
            this.SidebarTimer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // StudentTimer
            // 
            this.StudentTimer.Interval = 35;
            this.StudentTimer.Tick += new System.EventHandler(this.StudentTimer_Tick);
            // 
            // Studentcontianer
            // 
            this.Studentcontianer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.Studentcontianer.Controls.Add(this.button1);
            this.Studentcontianer.Controls.Add(this.StudentButton);
            this.Studentcontianer.Location = new System.Drawing.Point(3, 77);
            this.Studentcontianer.MaximumSize = new System.Drawing.Size(227, 120);
            this.Studentcontianer.MinimumSize = new System.Drawing.Size(227, 63);
            this.Studentcontianer.Name = "Studentcontianer";
            this.Studentcontianer.Size = new System.Drawing.Size(227, 63);
            this.Studentcontianer.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(70)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = global::MidTermProject.Properties.Resources.icons8_white_small_square_48;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(2, 65);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(221, 50);
            this.button1.TabIndex = 3;
            this.button1.Text = "                      Manage Students";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // StudentButton
            // 
            this.StudentButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.StudentButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.StudentButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.StudentButton.FlatAppearance.BorderSize = 0;
            this.StudentButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StudentButton.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentButton.ForeColor = System.Drawing.Color.White;
            this.StudentButton.Image = global::MidTermProject.Properties.Resources.icons8_cap_64;
            this.StudentButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StudentButton.Location = new System.Drawing.Point(3, 3);
            this.StudentButton.Name = "StudentButton";
            this.StudentButton.Size = new System.Drawing.Size(221, 59);
            this.StudentButton.TabIndex = 2;
            this.StudentButton.Text = "                           STUDENT";
            this.StudentButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StudentButton.UseVisualStyleBackColor = false;
            this.StudentButton.Click += new System.EventHandler(this.StudentButton_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.menu);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(181, 68);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(78, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "MENU";
            // 
            // menu
            // 
            this.menu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menu.Image = global::MidTermProject.Properties.Resources.menu;
            this.menu.Location = new System.Drawing.Point(9, 9);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(45, 38);
            this.menu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menu.TabIndex = 0;
            this.menu.TabStop = false;
            this.menu.Click += new System.EventHandler(this.menu_Click);
            // 
            // SideBar
            // 
            this.SideBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.SideBar.Controls.Add(this.panel1);
            this.SideBar.Controls.Add(this.Studentcontianer);
            this.SideBar.Controls.Add(this.AdvisorContainer);
            this.SideBar.Controls.Add(this.ProjectContainer);
            this.SideBar.Controls.Add(this.EvaluationContainer);
            this.SideBar.Controls.Add(this.GroupContainer);
            this.SideBar.Controls.Add(this.ReportContainer);
            this.SideBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.SideBar.Location = new System.Drawing.Point(0, 0);
            this.SideBar.MaximumSize = new System.Drawing.Size(184, 800);
            this.SideBar.MinimumSize = new System.Drawing.Size(80, 468);
            this.SideBar.Name = "SideBar";
            this.SideBar.Size = new System.Drawing.Size(80, 749);
            this.SideBar.TabIndex = 0;
            // 
            // AdvisorContainer
            // 
            this.AdvisorContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.AdvisorContainer.Controls.Add(this.button9);
            this.AdvisorContainer.Controls.Add(this.button2);
            this.AdvisorContainer.Controls.Add(this.Advisorbtn);
            this.AdvisorContainer.Location = new System.Drawing.Point(3, 146);
            this.AdvisorContainer.MaximumSize = new System.Drawing.Size(227, 150);
            this.AdvisorContainer.MinimumSize = new System.Drawing.Size(227, 63);
            this.AdvisorContainer.Name = "AdvisorContainer";
            this.AdvisorContainer.Size = new System.Drawing.Size(227, 63);
            this.AdvisorContainer.TabIndex = 4;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Image = global::MidTermProject.Properties.Resources.icons8_white_small_square_48;
            this.button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.Location = new System.Drawing.Point(1, 103);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(221, 50);
            this.button9.TabIndex = 4;
            this.button9.Text = "                      Assign Advisors";
            this.button9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = global::MidTermProject.Properties.Resources.icons8_white_small_square_48;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(2, 65);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(221, 50);
            this.button2.TabIndex = 3;
            this.button2.Text = "                      Manage Advisors";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Advisorbtn
            // 
            this.Advisorbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.Advisorbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Advisorbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Advisorbtn.FlatAppearance.BorderSize = 0;
            this.Advisorbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Advisorbtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Advisorbtn.ForeColor = System.Drawing.Color.White;
            this.Advisorbtn.Image = global::MidTermProject.Properties.Resources.icons8_consultation_50__1_;
            this.Advisorbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Advisorbtn.Location = new System.Drawing.Point(-3, 3);
            this.Advisorbtn.Name = "Advisorbtn";
            this.Advisorbtn.Size = new System.Drawing.Size(221, 59);
            this.Advisorbtn.TabIndex = 2;
            this.Advisorbtn.Text = "                            ADVISOR";
            this.Advisorbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Advisorbtn.UseVisualStyleBackColor = false;
            this.Advisorbtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // ProjectContainer
            // 
            this.ProjectContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.ProjectContainer.Controls.Add(this.button8);
            this.ProjectContainer.Controls.Add(this.button3);
            this.ProjectContainer.Controls.Add(this.projectbtn);
            this.ProjectContainer.Location = new System.Drawing.Point(3, 215);
            this.ProjectContainer.MaximumSize = new System.Drawing.Size(227, 150);
            this.ProjectContainer.MinimumSize = new System.Drawing.Size(227, 63);
            this.ProjectContainer.Name = "ProjectContainer";
            this.ProjectContainer.Size = new System.Drawing.Size(227, 63);
            this.ProjectContainer.TabIndex = 5;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Image = global::MidTermProject.Properties.Resources.icons8_white_small_square_48;
            this.button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.Location = new System.Drawing.Point(2, 101);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(221, 50);
            this.button8.TabIndex = 4;
            this.button8.Text = "                      Assign Projects";
            this.button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Image = global::MidTermProject.Properties.Resources.icons8_white_small_square_48;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(2, 65);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(221, 50);
            this.button3.TabIndex = 3;
            this.button3.Text = "                      Manage Projects";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // projectbtn
            // 
            this.projectbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.projectbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.projectbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.projectbtn.FlatAppearance.BorderSize = 0;
            this.projectbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.projectbtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.projectbtn.ForeColor = System.Drawing.Color.White;
            this.projectbtn.Image = global::MidTermProject.Properties.Resources.icons8_project_50;
            this.projectbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.projectbtn.Location = new System.Drawing.Point(-3, 3);
            this.projectbtn.Name = "projectbtn";
            this.projectbtn.Size = new System.Drawing.Size(221, 59);
            this.projectbtn.TabIndex = 2;
            this.projectbtn.Text = "                            PROJECT";
            this.projectbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.projectbtn.UseVisualStyleBackColor = false;
            this.projectbtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // EvaluationContainer
            // 
            this.EvaluationContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.EvaluationContainer.Controls.Add(this.button10);
            this.EvaluationContainer.Controls.Add(this.button4);
            this.EvaluationContainer.Controls.Add(this.Evaluationbtn);
            this.EvaluationContainer.Location = new System.Drawing.Point(3, 284);
            this.EvaluationContainer.MaximumSize = new System.Drawing.Size(227, 150);
            this.EvaluationContainer.MinimumSize = new System.Drawing.Size(227, 63);
            this.EvaluationContainer.Name = "EvaluationContainer";
            this.EvaluationContainer.Size = new System.Drawing.Size(227, 63);
            this.EvaluationContainer.TabIndex = 6;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Image = global::MidTermProject.Properties.Resources.icons8_white_small_square_48;
            this.button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.Location = new System.Drawing.Point(1, 103);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(221, 50);
            this.button10.TabIndex = 4;
            this.button10.Text = "                      Mark Evaluation";
            this.button10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Image = global::MidTermProject.Properties.Resources.icons8_white_small_square_48;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(2, 65);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(221, 50);
            this.button4.TabIndex = 3;
            this.button4.Text = "                      Manage Evaluation";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // Evaluationbtn
            // 
            this.Evaluationbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.Evaluationbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Evaluationbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Evaluationbtn.FlatAppearance.BorderSize = 0;
            this.Evaluationbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Evaluationbtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Evaluationbtn.ForeColor = System.Drawing.Color.White;
            this.Evaluationbtn.Image = global::MidTermProject.Properties.Resources.icons8_evaluation_64__1_;
            this.Evaluationbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Evaluationbtn.Location = new System.Drawing.Point(-3, 3);
            this.Evaluationbtn.Name = "Evaluationbtn";
            this.Evaluationbtn.Size = new System.Drawing.Size(221, 63);
            this.Evaluationbtn.TabIndex = 2;
            this.Evaluationbtn.Text = "                            EVALUATION";
            this.Evaluationbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Evaluationbtn.UseVisualStyleBackColor = false;
            this.Evaluationbtn.Click += new System.EventHandler(this.button5_Click);
            // 
            // GroupContainer
            // 
            this.GroupContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.GroupContainer.Controls.Add(this.button7);
            this.GroupContainer.Controls.Add(this.button5);
            this.GroupContainer.Controls.Add(this.button6);
            this.GroupContainer.Location = new System.Drawing.Point(3, 353);
            this.GroupContainer.MaximumSize = new System.Drawing.Size(227, 150);
            this.GroupContainer.MinimumSize = new System.Drawing.Size(227, 63);
            this.GroupContainer.Name = "GroupContainer";
            this.GroupContainer.Size = new System.Drawing.Size(227, 63);
            this.GroupContainer.TabIndex = 7;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Image = global::MidTermProject.Properties.Resources.icons8_white_small_square_48;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(2, 107);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(221, 50);
            this.button7.TabIndex = 4;
            this.button7.Text = "                        Assign Group";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Image = global::MidTermProject.Properties.Resources.icons8_white_small_square_48;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(2, 65);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(221, 50);
            this.button5.TabIndex = 3;
            this.button5.Text = "                        Add Group";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Image = global::MidTermProject.Properties.Resources.icons8_group_50;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(-3, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(221, 59);
            this.button6.TabIndex = 2;
            this.button6.Text = "                            GROUP";
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // ReportContainer
            // 
            this.ReportContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(55)))), ((int)(((byte)(60)))));
            this.ReportContainer.Controls.Add(this.button13);
            this.ReportContainer.Location = new System.Drawing.Point(3, 422);
            this.ReportContainer.MaximumSize = new System.Drawing.Size(227, 100);
            this.ReportContainer.MinimumSize = new System.Drawing.Size(227, 63);
            this.ReportContainer.Name = "ReportContainer";
            this.ReportContainer.Size = new System.Drawing.Size(227, 64);
            this.ReportContainer.TabIndex = 8;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Image = global::MidTermProject.Properties.Resources.icons8_report_card_50;
            this.button13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button13.Location = new System.Drawing.Point(-3, 3);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(221, 59);
            this.button13.TabIndex = 2;
            this.button13.Text = "                        GENRATE REPORT";
            this.button13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // AdvisorTimer
            // 
            this.AdvisorTimer.Interval = 35;
            this.AdvisorTimer.Tick += new System.EventHandler(this.AdvisorTimer_Tick);
            // 
            // ProjectTimer
            // 
            this.ProjectTimer.Interval = 35;
            this.ProjectTimer.Tick += new System.EventHandler(this.ProjectTimer_Tick);
            // 
            // EvaluationTimer
            // 
            this.EvaluationTimer.Interval = 35;
            this.EvaluationTimer.Tick += new System.EventHandler(this.EvaluationTimer_Tick);
            // 
            // GroupTimer
            // 
            this.GroupTimer.Interval = 35;
            this.GroupTimer.Tick += new System.EventHandler(this.GroupTimer_Tick);
            // 
            // main1
            // 
            this.main1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.main1.Location = new System.Drawing.Point(80, 0);
            this.main1.Name = "main1";
            this.main1.Size = new System.Drawing.Size(807, 749);
            this.main1.TabIndex = 11;
            // 
            // markEvaluation1
            // 
            this.markEvaluation1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.markEvaluation1.Location = new System.Drawing.Point(80, 0);
            this.markEvaluation1.Name = "markEvaluation1";
            this.markEvaluation1.Size = new System.Drawing.Size(807, 749);
            this.markEvaluation1.TabIndex = 10;
            this.markEvaluation1.Visible = false;
            // 
            // assignAdvisor1
            // 
            this.assignAdvisor1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.assignAdvisor1.Location = new System.Drawing.Point(80, 0);
            this.assignAdvisor1.Name = "assignAdvisor1";
            this.assignAdvisor1.Size = new System.Drawing.Size(807, 749);
            this.assignAdvisor1.TabIndex = 9;
            this.assignAdvisor1.Visible = false;
            // 
            // assignProject1
            // 
            this.assignProject1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.assignProject1.Location = new System.Drawing.Point(80, 0);
            this.assignProject1.Name = "assignProject1";
            this.assignProject1.Size = new System.Drawing.Size(807, 749);
            this.assignProject1.TabIndex = 8;
            this.assignProject1.Visible = false;
            // 
            // addSGroup1
            // 
            this.addSGroup1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addSGroup1.Location = new System.Drawing.Point(80, 0);
            this.addSGroup1.Name = "addSGroup1";
            this.addSGroup1.Size = new System.Drawing.Size(807, 749);
            this.addSGroup1.TabIndex = 7;
            this.addSGroup1.Visible = false;
            // 
            // veiwGroup1
            // 
            this.veiwGroup1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.veiwGroup1.Location = new System.Drawing.Point(80, 0);
            this.veiwGroup1.Name = "veiwGroup1";
            this.veiwGroup1.Size = new System.Drawing.Size(807, 749);
            this.veiwGroup1.TabIndex = 6;
            this.veiwGroup1.Visible = false;
            // 
            // evaluationVeiw1
            // 
            this.evaluationVeiw1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.evaluationVeiw1.Location = new System.Drawing.Point(80, 0);
            this.evaluationVeiw1.Name = "evaluationVeiw1";
            this.evaluationVeiw1.Size = new System.Drawing.Size(807, 749);
            this.evaluationVeiw1.TabIndex = 5;
            this.evaluationVeiw1.Visible = false;
            // 
            // projectVeiw1
            // 
            this.projectVeiw1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.projectVeiw1.Location = new System.Drawing.Point(80, 0);
            this.projectVeiw1.Name = "projectVeiw1";
            this.projectVeiw1.Size = new System.Drawing.Size(807, 749);
            this.projectVeiw1.TabIndex = 4;
            this.projectVeiw1.Visible = false;
            // 
            // veiwAdvisor1
            // 
            this.veiwAdvisor1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.veiwAdvisor1.Location = new System.Drawing.Point(80, 0);
            this.veiwAdvisor1.Name = "veiwAdvisor1";
            this.veiwAdvisor1.Size = new System.Drawing.Size(807, 749);
            this.veiwAdvisor1.TabIndex = 3;
            this.veiwAdvisor1.Visible = false;
            // 
            // student1
            // 
            this.student1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.student1.Location = new System.Drawing.Point(80, 0);
            this.student1.Name = "student1";
            this.student1.Size = new System.Drawing.Size(807, 749);
            this.student1.TabIndex = 2;
            this.student1.Visible = false;
            this.student1.Load += new System.EventHandler(this.student1_Load);
            // 
            // genrateReport1
            // 
            this.genrateReport1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.genrateReport1.Location = new System.Drawing.Point(80, 0);
            this.genrateReport1.Name = "genrateReport1";
            this.genrateReport1.Size = new System.Drawing.Size(807, 749);
            this.genrateReport1.TabIndex = 12;
            this.genrateReport1.Visible = false;
            this.genrateReport1.Load += new System.EventHandler(this.genrateReport1_Load);
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(887, 749);
            this.Controls.Add(this.genrateReport1);
            this.Controls.Add(this.main1);
            this.Controls.Add(this.markEvaluation1);
            this.Controls.Add(this.assignAdvisor1);
            this.Controls.Add(this.assignProject1);
            this.Controls.Add(this.addSGroup1);
            this.Controls.Add(this.veiwGroup1);
            this.Controls.Add(this.evaluationVeiw1);
            this.Controls.Add(this.projectVeiw1);
            this.Controls.Add(this.veiwAdvisor1);
            this.Controls.Add(this.student1);
            this.Controls.Add(this.SideBar);
            this.Name = "HomePage";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home Page";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Studentcontianer.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menu)).EndInit();
            this.SideBar.ResumeLayout(false);
            this.AdvisorContainer.ResumeLayout(false);
            this.ProjectContainer.ResumeLayout(false);
            this.EvaluationContainer.ResumeLayout(false);
            this.GroupContainer.ResumeLayout(false);
            this.ReportContainer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer SidebarTimer;
        private System.Windows.Forms.Timer StudentTimer;
        private System.Windows.Forms.Panel Studentcontianer;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button StudentButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox menu;
        private System.Windows.Forms.FlowLayoutPanel SideBar;
        private Student student1;
        private System.Windows.Forms.Panel AdvisorContainer;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Advisorbtn;
        private Advisor.VeiwAdvisor veiwAdvisor1;
        private System.Windows.Forms.Timer AdvisorTimer;
        private System.Windows.Forms.Panel ProjectContainer;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button projectbtn;
        private System.Windows.Forms.Timer ProjectTimer;
        private Project.ProjectVeiw projectVeiw1;
        private System.Windows.Forms.Panel EvaluationContainer;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button Evaluationbtn;
        private System.Windows.Forms.Timer EvaluationTimer;
        private Evaluation.EvaluationVeiw evaluationVeiw1;
        private System.Windows.Forms.Panel GroupContainer;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Timer GroupTimer;
        private Groups.VeiwGroup veiwGroup1;
        private System.Windows.Forms.Label label1;
        private Groups.AddSGroup addSGroup1;
        private System.Windows.Forms.Button button8;
        private Project.AssignProject assignProject1;
        private System.Windows.Forms.Button button9;
        private Advisor.AssignAdvisor assignAdvisor1;
        private System.Windows.Forms.Button button10;
        private Evaluation.MarkEvaluation markEvaluation1;
        private main main1;
        private System.Windows.Forms.Panel ReportContainer;
        private System.Windows.Forms.Button button13;
        private GenrateReport genrateReport1;
    }
}

