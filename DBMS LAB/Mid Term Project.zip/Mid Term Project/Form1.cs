﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MidTermProject.Groups;
using iTextSharp.text.pdf;
using iTextSharp.text;

namespace MidTermProject
{
    public partial class HomePage : Form
    {
        bool sidebarExpand;
        bool StudentContainer;
        bool AdvisorBag;
        bool projectBag;
        bool EvaluationBag;
        bool GroupBag;
        bool reportBag;
        public HomePage()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                SideBar.Width -= 10;
                if (SideBar.Width == SideBar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    SidebarTimer.Stop();
                }
            }
            else
            {
                SideBar.Width += 10;
                if (SideBar.Width == SideBar.MaximumSize.Width)
                {
                    sidebarExpand = true;
                    SidebarTimer.Stop();
                }

            }

        }

        private void menu_Click(object sender, EventArgs e)
        {
            SidebarTimer.Start();
        }

        private void StudentTimer_Tick(object sender, EventArgs e)
        {
            if (StudentContainer)
            {
                Studentcontianer.Height += 10;
                if (Studentcontianer.Height == Studentcontianer.MaximumSize.Height)
                {
                    StudentContainer = false;
                    StudentTimer.Stop();
                }
            }
            else
            {
                Studentcontianer.Height -= 10;
                if (Studentcontianer.Height == Studentcontianer.MinimumSize.Height)
                {
                    StudentContainer = true;
                    StudentTimer.Stop();
                }

            }

        }
   

        private void StudentButton_Click(object sender, EventArgs e)
        {
            StudentTimer.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            student1.Visible = true;
            veiwAdvisor1.Visible = false;
            projectVeiw1.Visible = false;
            evaluationVeiw1.Visible = false;
            veiwGroup1.Visible = false;
            addSGroup1.Visible = false;
            assignProject1.Visible = false;
            assignAdvisor1.Visible = false;
            markEvaluation1.Visible = false;
            main1.Visible = false;
            genrateReport1.Visible = false;

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void student1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdvisorTimer.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            veiwAdvisor1.Visible = true;
            student1.Visible = false;
            projectVeiw1.Visible = false;
            evaluationVeiw1.Visible = false;
            veiwGroup1.Visible = false;
            addSGroup1.Visible = false;
            assignProject1.Visible = false;
            assignAdvisor1.Visible = false;
            markEvaluation1.Visible = false;
            genrateReport1.Visible = false;
            main1.Visible = false;
        }

        private void AdvisorTimer_Tick(object sender, EventArgs e)
        {
            if (AdvisorBag)
            {
                AdvisorContainer.Height += 10;
                if (AdvisorContainer.Height == AdvisorContainer.MaximumSize.Height)
                {
                    AdvisorBag = false;
                    AdvisorTimer.Stop();
                }
            }
            else
            {
                AdvisorContainer.Height -= 10;
                if (AdvisorContainer.Height == AdvisorContainer.MinimumSize.Height)
                {
                    AdvisorBag = true;
                    AdvisorTimer.Stop();
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ProjectTimer.Start();
        }

        private void ProjectTimer_Tick(object sender, EventArgs e)
        {
            if (projectBag)
            {
                ProjectContainer.Height += 10;
                if (ProjectContainer.Height == ProjectContainer.MaximumSize.Height)
                {
                    projectBag = false;
                    ProjectTimer.Stop();
                }
            }
            else
            {
                ProjectContainer.Height -= 10;
                if (ProjectContainer.Height == ProjectContainer.MinimumSize.Height)
                {
                    projectBag = true;
                    ProjectTimer.Stop();
                }

            }

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            projectVeiw1.Visible = true;
            student1.Visible = false;
            veiwAdvisor1.Visible = false;
            evaluationVeiw1.Visible = false;
            veiwGroup1.Visible = false;
            addSGroup1.Visible = false;
            assignProject1.Visible = false;
            markEvaluation1.Visible = false;
            assignAdvisor1.Visible = false;
            main1.Visible = false;
            genrateReport1.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            EvaluationTimer.Start();
        }

        private void EvaluationTimer_Tick(object sender, EventArgs e)
        {
            if (EvaluationBag)
            {
                EvaluationContainer.Height += 10;
                if (EvaluationContainer.Height == EvaluationContainer.MaximumSize.Height)
                {
                    EvaluationBag = false;
                    EvaluationTimer.Stop();

                }
            }
            else
            {
                EvaluationContainer.Height -= 10;
                if (EvaluationContainer.Height == EvaluationContainer.MinimumSize.Height)
                {
                    EvaluationBag = true;
                    EvaluationTimer.Stop();
                }

            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            evaluationVeiw1.Visible = true;
            genrateReport1.Visible = false;
            projectVeiw1.Visible = false;
            student1.Visible = false;
            veiwAdvisor1.Visible = false;
            veiwGroup1.Visible = false;
            addSGroup1.Visible = false;
            assignProject1.Visible = false;
            assignAdvisor1.Visible = false;
            markEvaluation1.Visible = false;
            main1.Visible = false;

        }

        private void GroupTimer_Tick(object sender, EventArgs e)
        {
            if (GroupBag)
            {
                GroupContainer.Height += 10;
                if (GroupContainer.Height == GroupContainer.MaximumSize.Height)
                {
                    GroupBag = false;
                    GroupTimer.Stop();

                }
            }
            else
            {
                GroupContainer.Height -= 10;
                if (GroupContainer.Height == GroupContainer.MinimumSize.Height)
                {
                    GroupBag = true;
                    GroupTimer.Stop();
                }

            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            GroupTimer.Start();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            evaluationVeiw1.Visible = false;
            genrateReport1.Visible = false;
            projectVeiw1.Visible = false;
            student1.Visible = false;
            veiwAdvisor1.Visible = false;
            veiwGroup1.Visible = true;
            addSGroup1.Visible = false;
            assignProject1.Visible = false;
            assignAdvisor1.Visible = false;
            markEvaluation1.Visible = false;
            main1.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            addSGroup1.Visible = true;
            evaluationVeiw1.Visible = false;
            projectVeiw1.Visible = false;
            student1.Visible = false;
            veiwAdvisor1.Visible = false;
            veiwGroup1.Visible = false;
            assignProject1.Visible = false;
            assignAdvisor1.Visible = false;
            markEvaluation1.Visible = false;
            main1.Visible = false;
            genrateReport1.Visible = false;

        }

        private void button8_Click(object sender, EventArgs e)
        {
            assignProject1.Visible = true;
            addSGroup1.Visible = false;
            evaluationVeiw1.Visible = false;
            projectVeiw1.Visible = false;
            student1.Visible = false;
            veiwAdvisor1.Visible = false;
            veiwGroup1.Visible = false;
            assignAdvisor1.Visible = false;
            markEvaluation1.Visible = false;
            main1.Visible = false;
            genrateReport1.Visible = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            assignAdvisor1.Visible = true;
            assignProject1.Visible = false;
            addSGroup1.Visible = false;
            evaluationVeiw1.Visible = false;
            projectVeiw1.Visible = false;
            student1.Visible = false;
            veiwAdvisor1.Visible = false;
            veiwGroup1.Visible = false;
            markEvaluation1.Visible = false;
            main1.Visible = false;
            genrateReport1.Visible = false;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            markEvaluation1.Visible = true;
            assignAdvisor1.Visible = false;
            assignProject1.Visible = false;
            addSGroup1.Visible = false;
            evaluationVeiw1.Visible = false;
            projectVeiw1.Visible = false;
            student1.Visible = false;
            veiwAdvisor1.Visible = false;
            veiwGroup1.Visible = false;
            main1.Visible = false;
            genrateReport1.Visible = false;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            genrateReport1.Visible = true;
            markEvaluation1.Visible = false;
            assignAdvisor1.Visible = false;
            assignProject1.Visible = false;
            addSGroup1.Visible = false;
            evaluationVeiw1.Visible = false;
            projectVeiw1.Visible = false;
            student1.Visible = false;
            veiwAdvisor1.Visible = false;
            veiwGroup1.Visible = false;
            main1.Visible = false;
        }

        private void genrateReport1_Load(object sender, EventArgs e)
        {

        }
    }
}
