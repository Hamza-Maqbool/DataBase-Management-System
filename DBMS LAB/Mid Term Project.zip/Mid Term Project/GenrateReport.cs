﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.Data.SqlClient;
using System.IO;

namespace MidTermProject
{
    public partial class GenrateReport : UserControl
    {
        public GenrateReport()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            //List of Project
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select P.Title , P.Description , L1.Value as Role , P1.FirstName , P1.LastName , P1.Email , L.Value as Gender , Pa.AssignmentDate\r\nfrom Project as P\r\njoin ProjectAdvisor as Pa\r\non P.Id = Pa.ProjectId\r\njoin Person as P1\r\non P1.Id = Pa.AdvisorId\r\njoin Lookup as L\r\non L.Id = P1.Gender\r\njoin Lookup as L1\r\non L1.Id = Pa.AdvisorRole\r\ngroup by P.Title , P.Description , L1.Value , P1.FirstName , P1.LastName , P1.Email , L.Value , Pa.AssignmentDate", con);
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            Projects.DataSource = dataTable;

            //List of Students
            SqlCommand cmd1 = new SqlCommand("select S.RegistrationNo , P.FirstName , P.LastName , P.Contact , P.Email , P.DateOfBirth , L.Value as Gender\r\nfrom Student as S\r\njoin Person as P\r\non S.Id = P.Id\r\njoin Lookup as L\r\non L.Id = P.Gender", con);
            SqlDataReader sqlData1 = cmd1.ExecuteReader();
            DataTable dataTable1 = new DataTable();
            dataTable1.Load(sqlData1);
            Students.DataSource = dataTable1;


            //Mark Sheets
            SqlCommand cmd2 = new SqlCommand("select Q1.[Group ID] , Q1.Created_On , Q1.FirstName , Q1.LastName , Q1.Gender , Q1.Email , Q1.Title , Q1.Description , Q1.Name as Evaluation , Q1.ObtainedMarks , Q1.TotalMarks , Q1.TotalWeightage , Q1.[Obtained Weightage] , Q2.Obtained \r\nfrom (select G.Id as [Group ID] , G.Created_On ,P.Id, P.FirstName , P.LastName , L.Value as Gender , P.Email , Pr.Title , Pr.Description , E.Name , Ge.ObtainedMarks ,  E.TotalMarks , E.TotalWeightage , (Ge.ObtainedMarks * E.TotalWeightage/ E.TotalMarks) as [Obtained Weightage] \r\nfrom dbo.[Group] as G\r\njoin GroupEvaluation as Ge\r\non Ge.GroupId = G.Id\r\njoin GroupProject as Gp\r\non Gp.GroupId = G.Id\r\njoin GroupStudent as Gs\r\non Gs.GroupId = G.Id\r\njoin Person as P\r\non P.Id = Gs.StudentId\r\njoin Project as Pr\r\non Pr.Id = Gp.ProjectId\r\njoin Lookup as L\r\non L.Id = P.Gender\r\njoin Evaluation as E\r\non E.Id = Ge.EvaluationId\r\nwhere Gs.Status = 3\r\ngroup by G.Id , G.Created_On ,P.Id, P.FirstName , P.LastName , L.Value  , P.Email , Pr.Title , Pr.Description , E.Name , Ge.ObtainedMarks ,  E.TotalMarks , E.TotalWeightage , (Ge.ObtainedMarks * E.TotalWeightage/ E.TotalMarks )\r\n) as Q1\r\n\r\njoin (select SUM(S.[Obtained Weightage]) as Obtained ,  S.Id\r\nfrom dbo.[Group] as G\r\njoin (select G.Id as [Group ID] , G.Created_On ,P.Id , P.FirstName , P.LastName , L.Value as Gender , P.Email , Pr.Title , Pr.Description , E.Name , Ge.ObtainedMarks ,  E.TotalMarks , E.TotalWeightage , (Ge.ObtainedMarks * E.TotalWeightage/ E.TotalMarks) as [Obtained Weightage] \r\nfrom dbo.[Group] as G\r\njoin GroupEvaluation as Ge\r\non Ge.GroupId = G.Id\r\njoin GroupProject as Gp\r\non Gp.GroupId = G.Id\r\njoin GroupStudent as Gs\r\non Gs.GroupId = G.Id\r\njoin Person as P\r\non P.Id = Gs.StudentId\r\njoin Project as Pr\r\non Pr.Id = Gp.ProjectId\r\njoin Lookup as L\r\non L.Id = P.Gender\r\njoin Evaluation as E\r\non E.Id = Ge.EvaluationId\r\nwhere Gs.Status = 3\r\ngroup by G.Id , G.Created_On ,P.Id , P.FirstName , P.LastName , L.Value  , P.Email , Pr.Title , Pr.Description , E.Name , Ge.ObtainedMarks ,  E.TotalMarks , E.TotalWeightage , (Ge.ObtainedMarks * E.TotalWeightage/ E.TotalMarks )\r\n) as S\r\non S.[Group ID] = G.Id\r\ngroup by S.FirstName , S.LastName  , S.Id) as Q2\r\n\r\non Q1.Id = Q2.Id", con);
            SqlDataReader sqlData2 = cmd2.ExecuteReader();
            DataTable dataTable2 = new DataTable();
            dataTable2.Load(sqlData2);
            MarkSheet.DataSource = dataTable2;

        }
     

        private void ProjectReport_Click(object sender, EventArgs e)
        {
            if (Projects.Rows.Count > 0)

            {

                SaveFileDialog save = new SaveFileDialog();

                save.Filter = "PDF (*.pdf)|*.pdf";

                save.FileName = "Projects.pdf";

                bool ErrorMessage = false;

                if (save.ShowDialog() == DialogResult.OK)

                {

                    if (File.Exists(save.FileName))

                    {

                        try

                        {

                            File.Delete(save.FileName);

                        }

                        catch (Exception ex)

                        {

                            ErrorMessage = true;

                            MessageBox.Show("Unable to wride data in disk" + ex.Message);

                        }

                    }

                    if (!ErrorMessage)

                    {

                        try

                        {

                            PdfPTable pTable = new PdfPTable(Projects.Columns.Count);

                            pTable.DefaultCell.Padding = 2;

                            pTable.WidthPercentage = 100;

                            pTable.HorizontalAlignment = Element.ALIGN_LEFT;

                            foreach (DataGridViewColumn col in Projects.Columns)

                            {

                                PdfPCell pCell = new PdfPCell(new Phrase(col.HeaderText));

                                pTable.AddCell(pCell);

                            }

                            foreach (DataGridViewRow viewRow in Projects.Rows)

                            {

                                foreach (DataGridViewCell dcell in viewRow.Cells)

                                {

                                    pTable.AddCell(dcell.Value.ToString());

                                }

                            }

                            using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create))

                            {

                                Document document = new Document(PageSize.A4, 8f, 16f, 16f, 8f);

                                PdfWriter.GetInstance(document, fileStream);

                                document.Open();

                                document.Add(pTable);

                                document.Close();

                                fileStream.Close();

                            }

                            MessageBox.Show("Data Export Successfully", "info");

                        }

                        catch (Exception ex)

                        {

                            MessageBox.Show("Error while exporting Data" + ex.Message);

                        }

                    }

                }

            }

            else

            {

                MessageBox.Show("No Record Found", "Info");

            }
        }

        private void ListStudents_Click(object sender, EventArgs e)
        {
            if (Students.Rows.Count > 0)

            {

                SaveFileDialog save = new SaveFileDialog();

                save.Filter = "PDF (*.pdf)|*.pdf";

                save.FileName = "Students.pdf";

                bool ErrorMessage = false;

                if (save.ShowDialog() == DialogResult.OK)

                {

                    if (File.Exists(save.FileName))

                    {

                        try

                        {

                            File.Delete(save.FileName);

                        }

                        catch (Exception ex)

                        {

                            ErrorMessage = true;

                            MessageBox.Show("Unable to wride data in disk" + ex.Message);

                        }

                    }

                    if (!ErrorMessage)

                    {

                        try

                        {

                            PdfPTable pTable = new PdfPTable(Students.Columns.Count);

                            pTable.DefaultCell.Padding = 2;

                            pTable.WidthPercentage = 100;

                            pTable.HorizontalAlignment = Element.ALIGN_LEFT;

                            foreach (DataGridViewColumn col in Students.Columns)

                            {

                                PdfPCell pCell = new PdfPCell(new Phrase(col.HeaderText));

                                pTable.AddCell(pCell);

                            }

                            foreach (DataGridViewRow viewRow in Students.Rows)

                            {

                                foreach (DataGridViewCell dcell in viewRow.Cells)

                                {

                                    pTable.AddCell(dcell.Value.ToString());

                                }

                            }

                            using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create))

                            {

                                Document document = new Document(PageSize.A4, 8f, 16f, 16f, 8f);

                                PdfWriter.GetInstance(document, fileStream);

                                document.Open();

                                document.Add(pTable);

                                document.Close();

                                fileStream.Close();

                            }

                            MessageBox.Show("Data Export Successfully", "info");

                        }

                        catch (Exception ex)

                        {

                            MessageBox.Show("Error while exporting Data" + ex.Message);

                        }

                    }

                }

            }

            else

            {

                MessageBox.Show("No Record Found", "Info");

            }
        }

        private void GenerateMarksheets_Click(object sender, EventArgs e)
        {
            if (MarkSheet.Rows.Count > 0)

            {

                SaveFileDialog save = new SaveFileDialog();

                save.Filter = "PDF (*.pdf)|*.pdf";

                save.FileName = "MarkSheet.pdf";

                bool ErrorMessage = false;

                if (save.ShowDialog() == DialogResult.OK)

                {

                    if (File.Exists(save.FileName))

                    {

                        try

                        {

                            File.Delete(save.FileName);

                        }

                        catch (Exception ex)

                        {

                            ErrorMessage = true;

                            MessageBox.Show("Unable to wride data in disk" + ex.Message);

                        }

                    }

                    if (!ErrorMessage)

                    {

                        try

                        {

                            PdfPTable pTable = new PdfPTable(MarkSheet.Columns.Count);

                            pTable.DefaultCell.Padding = 2;

                            pTable.WidthPercentage = 100;

                            pTable.HorizontalAlignment = Element.ALIGN_LEFT;

                            foreach (DataGridViewColumn col in MarkSheet.Columns)

                            {

                                PdfPCell pCell = new PdfPCell(new Phrase(col.HeaderText));

                                pTable.AddCell(pCell);

                            }

                            foreach (DataGridViewRow viewRow in MarkSheet.Rows)

                            {

                                foreach (DataGridViewCell dcell in viewRow.Cells)

                                {

                                    pTable.AddCell(dcell.Value.ToString());

                                }

                            }

                            using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create))

                            {

                                Document document = new Document(PageSize.A4, 8f, 16f, 16f, 8f);

                                PdfWriter.GetInstance(document, fileStream);

                                document.Open();

                                document.Add(pTable);

                                document.Close();

                                fileStream.Close();

                            }

                            MessageBox.Show("Data Export Successfully", "info");

                        }

                        catch (Exception ex)

                        {

                            MessageBox.Show("Error while exporting Data" + ex.Message);

                        }

                    }

                }

            }

            else

            {

                MessageBox.Show("No Record Found", "Info");

            }
        }
    }
}
