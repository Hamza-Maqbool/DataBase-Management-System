﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Groups
{
    public partial class AddGroup : Form
    {
        public static List<int> RecordGropId = new List<int>();
        public AddGroup()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("insert into [dbo].[Group](Created_On) values (@Created_On); SELECT SCOPE_IDENTITY()", con);
            guna2DateTimePicker1.Format = DateTimePickerFormat.Custom;
            guna2DateTimePicker1.CustomFormat = "yyyy-MM-dd";
            cmd.Parameters.AddWithValue("@Created_On", guna2DateTimePicker1.Text);
            int id = Convert.ToInt32(cmd.ExecuteScalar());
            RecordGropId.Add(id);
            MessageBox.Show("Group Added Successfully...");
            this.Close();

        }
        public static void AddToFile()
        {

        }
    }
}
