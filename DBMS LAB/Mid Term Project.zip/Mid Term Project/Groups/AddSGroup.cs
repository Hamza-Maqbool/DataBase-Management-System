﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Groups
{
    public partial class AddSGroup : UserControl
    {
        private static int ID = -1;
        int Groupid, Studentid,Status;
        String Assignmentdate;
        public AddSGroup()
        {
            InitializeComponent();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            refresh();
        }
        private void refresh()
        {
            dataGridView1.DataSource = null;
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select G.GroupId , G.StudentId  , G.AssignmentDate , L.Value as Status\r\n  from GroupStudent as G \r\njoin Lookup as L\r\n on L.Id = G.Status");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            dataGridView1.DataSource = dataTable;
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            AddStudentGroup f = new AddStudentGroup();
            f.Show();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
                try
                {
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("update GroupStudent SET Status = @Status where GroupId = @ID ");

                   cmd.Parameters.AddWithValue("@ID", Groupid);
                    cmd.Parameters.AddWithValue("@Status",4);
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully Updated Student Status...");
                    refresh();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Groupid = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
        }
    }
}
