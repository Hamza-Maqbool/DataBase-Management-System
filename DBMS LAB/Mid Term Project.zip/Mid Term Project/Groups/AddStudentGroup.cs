﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MidTermProject.Groups;

namespace MidTermProject.Groups
{
    public partial class AddStudentGroup : Form
    {
        public AddStudentGroup()
        {
            InitializeComponent();
        }

        private void Add_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            try
            {

                var con = Configuration.getInstance().getConnection();
                string query = "Select StudentId from GroupStudent as G where G.GroupId = @id and G.Status = @Status ";
                SqlCommand cmd2 = new SqlCommand(query, con);
                cmd2.Parameters.AddWithValue("@id", int.Parse(GroupIdTextBox.Text));
                cmd2.Parameters.AddWithValue("@Status", 3);
                int check = Convert.ToInt32(cmd2.ExecuteScalar());
                if(check == int.Parse(txtStudentId.Text))
                {
                    MessageBox.Show("Student Already Exist...");
                }
                else 
                { 
                    SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[GroupStudent](GroupId,StudentId,Status,AssignmentDate) VALUES (@GroupId,@StudentId,@Status,@AssignmentDate); ", con);
                    cmd.Parameters.AddWithValue("@GroupId", int.Parse(GroupIdTextBox.Text));
                    cmd.Parameters.AddWithValue("@StudentId", int.Parse(txtStudentId.Text));
                    cmd.Parameters.AddWithValue("@Status", 3);
                    cmd.Parameters.AddWithValue("@AssignmentDate", System.DateTime.Now);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully saved...");
                    this.Close();
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
