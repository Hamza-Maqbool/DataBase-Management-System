﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Project
{
    public partial class AddAssignProject : Form
    {
        public AddAssignProject()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(pidtxt.Text) || string.IsNullOrEmpty(gidtxt.Text))
            {
                MessageBox.Show("Please fill all queries...");
            }
            else
            {
                try
                {
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("insert into GroupProject(ProjectId , GroupId, AssignmentDate) values (@ProjectId , @GroupId ,@AssignmentDate)", con);
                    cmd.Parameters.AddWithValue("@ProjectId", int.Parse(pidtxt.Text));
                    cmd.Parameters.AddWithValue("@GroupId", int.Parse(gidtxt.Text));
                    guna2DateTimePicker1.Format = DateTimePickerFormat.Custom;
                    guna2DateTimePicker1.CustomFormat = "yyyy-MM-dd";
                    cmd.Parameters.AddWithValue("@AssignmentDate", guna2DateTimePicker1.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Project Assign Successfully...");
                    this.Close();
                }
                catch 
                {
                    MessageBox.Show("ID NOT FOUND");
                }
                
            }
        }
    }
}
