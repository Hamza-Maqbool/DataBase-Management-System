﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Project
{
    public partial class ProjectVeiw : UserControl
    {
        private int ID = -1;
        private string Title, Description;
        public ProjectVeiw()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            AddProject f = new AddProject();
            f.Show();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            refresh();
        }

        private void refresh()
        {
            dataGridView1.DataSource = null;
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select Id , Title , Description from Project");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            dataGridView1.DataSource = dataTable;
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            if (ID != -1)
            {
                try
                {
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("delete Project where Id = @ID");
                    cmd.Parameters.AddWithValue("@ID", ID);
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Has Been Deleted Successfully...");
                    refresh();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }

            }
            else
            {
                MessageBox.Show("Please Select A Row To Deleteo...");
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (ID != -1)
            {
                Form form = new UpdateProject(Title, Description, ID);
                form.Show();
            }

            else
            {
                MessageBox.Show("Please select an entry to edit...");
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Title = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            Description = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            ID = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
        }
    }
}
