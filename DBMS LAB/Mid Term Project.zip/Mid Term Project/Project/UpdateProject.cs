﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Project
{
    public partial class UpdateProject : Form
    {
       
        private static int ID;
        public UpdateProject(string Title, string Description, int IDs)
        {
            InitializeComponent();
            txtDescription.Text = Description;
            txtTitle.Text = Title;
            ID = IDs;
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtDescription.Text) || string.IsNullOrEmpty(txtTitle.Text))
            {
                MessageBox.Show("Please fill all queries...");
            }
            else
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("update Project set Title = @Title , Description = @Description where Id = @ID", con);
                cmd.Parameters.AddWithValue("@Title", txtTitle.Text);
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("@ID", ID);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Project Updated Successfully...");
                this.Close();
            }
        }
    }
}
