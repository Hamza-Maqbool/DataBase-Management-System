﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MidTermProject.Students
{
    public partial class AddStudents : Form
    {
        public AddStudents()
        {
            InitializeComponent();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            bool flag = true;

            if (flag)
            {
                if (string.IsNullOrEmpty(txtContactNumber.Text) || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtFirstName.Text) || string.IsNullOrEmpty(txtLastName.Text) || string.IsNullOrEmpty(txtRegNo.Text))
                {
                    MessageBox.Show("Please Fill All The Queries...");
                    flag = false;
                }
            }
            try
            {
                if (flag)
                {
                    if (!string.IsNullOrEmpty(txtContactNumber.Text) && !string.IsNullOrEmpty(txtEmail.Text) && !string.IsNullOrEmpty(txtFirstName.Text) && !string.IsNullOrEmpty(txtLastName.Text) && !string.IsNullOrEmpty(txtRegNo.Text))
                    {
                        int gender = 0;
                        var con = Configuration.getInstance().getConnection();
                        SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[Person](FirstName,LastName,Contact,Email,DateOfBirth,Gender) VALUES (@FirstName,@LastName, @Contact,@Email,@DOB, @Gender)", con);
                        SqlCommand cmd1 = new SqlCommand("insert into [dbo].[Student](Id,RegistrationNo) VALUES ((SELECT Id FROM Person WHERE FirstName = @FirstName AND LastName=@LastName AND Contact=@Contact AND Email=@Email AND DateOfBirth=@DOB AND Gender=@Gender) ,@RegistrationNo)", con);
                        cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                        cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                        cmd.Parameters.AddWithValue("@Contact", txtContactNumber.Text);
                        cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                        cmd.Parameters.AddWithValue("@RegistrationNo", txtRegNo.Text);
                        cmd1.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                        cmd1.Parameters.AddWithValue("@LastName", txtLastName.Text);
                        cmd1.Parameters.AddWithValue("@Contact", txtContactNumber.Text);
                        cmd1.Parameters.AddWithValue("@Email", txtEmail.Text);
                        cmd1.Parameters.AddWithValue("@RegistrationNo", txtRegNo.Text);
                        if (Gender.SelectedIndex == 1)
                        {
                            gender = 2;
                        }
                        if (Gender.SelectedIndex == 2)
                        {
                            gender = 1;
                        }
                        guna2DateTimePicker1.Format = DateTimePickerFormat.Custom;
                        guna2DateTimePicker1.CustomFormat = "yyyy-MM-dd";
                        cmd.Parameters.AddWithValue("@Gender", gender);
                        cmd.Parameters.AddWithValue("@DOB", guna2DateTimePicker1.Text);
                        cmd1.Parameters.AddWithValue("@Gender", gender);
                        cmd1.Parameters.AddWithValue("@DOB", guna2DateTimePicker1.Text);
                        cmd.ExecuteNonQuery();
                        cmd1.ExecuteNonQuery();
                        MessageBox.Show("Successfully saved");
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Gender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       
    }
}
