﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MidTermProject.Students;

namespace MidTermProject
{

    public partial class Student : UserControl
    {

        private static int ID = -1;
        string FirstName, RegistrationNumber;
        string LastName, Contact, Email, DOB;
        int Gen;
        public Student()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            AddStudents form = new AddStudents();
            form.Show();
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select S.Id , S.RegistrationNo , P.FirstName , P.LastName , P.Contact , P.DateOfBirth , P.Email , L.Value as Gender \r\nfrom Student as S\r\njoin Person as P\r\non S.Id = P.Id\r\njoin Lookup as L\r\non L.Id = P.Gender");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            dataGridView1.DataSource = dataTable;
        }
        private void ViewStudents_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select S.Id , S.RegistrationNo , P.FirstName , P.LastName , P.Contact , P.DateOfBirth , P.Email , L.Value as Gender \r\nfrom Student as S\r\njoin Person as P\r\non S.Id = P.Id\r\njoin Lookup as L\r\non L.Id = P.Gender");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            dataGridView1.DataSource = dataTable;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (ID != -1)
            {
                Form form = new UpdateStudent(FirstName, LastName, Contact, Email, DOB, Gen, RegistrationNumber, ID);
                form.Show();
                ID = -1;
            }
            else
            {
                MessageBox.Show("Please select an entry to edit...");
            }
        }

        private void dataGridView1_RowHeaderMouseClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            RegistrationNumber = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            FirstName = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            LastName = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            Contact = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            DOB = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            Email = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            if (dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString() == "Male")
            {
                Gen = 1;
            }
            else
            { 
                Gen = 2; 
            }

        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select S.Id , S.RegistrationNo , P.FirstName , P.LastName , P.Contact , P.DateOfBirth , P.Email , L.Value as Gender \r\nfrom Student as S\r\njoin Person as P\r\non S.Id = P.Id\r\njoin Lookup as L\r\non L.Id = P.Gender");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            dataGridView1.DataSource = dataTable;
        }
        private void refresh()
        {
            dataGridView1.DataSource = null;
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select S.Id , S.RegistrationNo , P.FirstName , P.LastName , P.Contact , P.DateOfBirth , P.Email , L.Value as Gender \r\nfrom Student as S\r\njoin Person as P\r\non S.Id = P.Id\r\njoin Lookup as L\r\non L.Id = P.Gender");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            dataGridView1.DataSource = dataTable;
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            if (ID != -1)
            {
                try
                {
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("delete Student where Id = @ID; delete Person where Id = @ID;");
                    cmd.Parameters.AddWithValue("@ID", ID);
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Has Been Deleted Successfully...");
                    refresh();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }

            }
            else
            {
                MessageBox.Show("Please Select A Row To Delete...");
            }
        }
        
    }
}
